
import { 
  Order, Product, Notification, AuditLog, UserRole, 
  CreativeMaterial, CreativeProject, CreativeEmployee, 
  CreativeBudget, CreativeContract, CreativeFinanceEntry, 
  CreativePermission, City, Address, CarboTask, Courier, Store, Ticket, 
  Vehicle, MarketingCampaign, Partner, PageContent, 
  ChatSession, Occurrence, FraudAlert, ChatMessage
} from '../types';

class CarboSystem {
  private maintenanceMode: boolean = false;
  private weatherCondition: 'SUNNY' | 'RAINY' | 'STORM' = 'SUNNY';
  
  // Creative Specialized Data
  private creativeMaterials: CreativeMaterial[] = [];
  private creativeProjects: CreativeProject[] = [];
  private creativeEmployees: CreativeEmployee[] = [];
  private creativeBudgets: CreativeBudget[] = [];
  private creativeContracts: CreativeContract[] = [];
  private creativeFinance: CreativeFinanceEntry[] = [];

  // Core Carbo Data
  private users: any[] = [
    { id: 'u1', cpf: '111', password: '123', role: UserRole.ADMIN, name: 'Admin Master', status: 'APPROVED' },
    { id: 'guilherme', cpf: 'guilherme', password: 'meriva1515', role: UserRole.VENDOR, name: 'Guilherme', storeId: 'creative_1', status: 'APPROVED' },
    { id: 'u3', cpf: '333', password: '123', role: UserRole.DELIVERY, name: 'Entregador', status: 'APPROVED' },
    { id: 'C1', cpf: '444', password: '123', role: UserRole.CLIENT, name: 'Cliente', status: 'APPROVED' }
  ];
  
  private auditLogs: AuditLog[] = [];
  private notifications: Notification[] = [];
  private subscribers: Function[] = [];
  private stores: Store[] = [];
  private tasks: CarboTask[] = [];
  private orders: Order[] = [];
  private cities: City[] = [];
  private transactions: any[] = [];
  private addresses: Record<string, Address[]> = {};

  constructor() {
    this.initMockData();
    this.initCreativeData();
  }

  private initMockData() {
    this.stores = [
      { id: 'creative_1', name: 'Creative Marcenaria', category: 'Móveis', isOpen: true, rating: 5.0, image: '', deliveryFee: 0, minTime: 0, maxTime: 0, rankingPosition: { daily: 1 } }
    ];
    this.cities = [{ id: '1', name: 'Curitiba', uf: 'PR', neighborhoods: ['Centro', 'Batel'], active: true }];
  }

  private initCreativeData() {
    this.creativeMaterials = [
      { id: 'm1', name: 'MDF Louro Freijó 18mm', category: 'MADEIRA', quantity: 12, unit: 'Chapas', minStock: 5 },
      { id: 'm2', name: 'MDF Branco 15mm', category: 'MADEIRA', quantity: 3, unit: 'Chapas', minStock: 10 }
    ];

    this.creativeEmployees = [
      { 
        id: 'e1', name: 'Ricardo Marceneiro', role: 'Marceneiro Sênior', username: 'ricardo', status: 'ATIVO', 
        permissions: [
          { module: 'Kanban', access: 'EDIT' }, 
          { module: 'Estoque', access: 'VIEW' },
          { module: 'Projetos', access: 'VIEW' }
        ], lastActive: '10 min'
      }
    ];

    this.creativeBudgets = [
      { id: 'B1', clientName: 'Roberto Almeida', description: 'Armário de Cozinha', materials: 'MDF Freijó', laborValue: 2000, totalValue: 4500, deadline: '2025-06-15', status: 'APROVADO', createdAt: Date.now() }
    ];

    this.creativeContracts = [
      { id: 'CON1', budgetId: 'B1', clientName: 'Roberto Almeida', projectName: 'Cozinha Completa', value: 4500, deadline: '2025-06-15', status: 'EM_ANDAMENTO' }
    ];

    this.creativeProjects = [
      { id: 'CP1', clientName: 'Roberto Almeida', furnitureType: 'Cozinha', description: 'Armário superior', measurements: '2400x600', material: 'MDF Freijó', deadline: '2025-06-15', value: 4500, status: 'PRODUCAO', createdAt: Date.now() }
    ];

    this.creativeFinance = [
      { id: 'F1', description: 'Venda Cozinha Roberto', type: 'ENTRADA', category: 'RECEITA', value: 4500, date: '2025-05-10', relatedId: 'CON1' },
      { id: 'F2', description: 'Compra MDF Louro Freijó', type: 'SAIDA', category: 'MATERIAIS', value: 1200, date: '2025-05-12' }
    ];
  }

  // --- CREATIVE ACTIONS ---

  public addEmployee(emp: Omit<CreativeEmployee, 'id' | 'lastActive'>) {
    const newEmp = { ...emp, id: `e${Date.now()}`, lastActive: 'Nunca', mustChangePassword: true };
    this.creativeEmployees.push(newEmp);
    this.logAudit('Guilherme', UserRole.VENDOR, 'CREATE_EMPLOYEE', `Funcionário ${emp.name} criado`, 'INFO');
    this.emitChange();
  }

  public updateEmployee(id: string, data: Partial<CreativeEmployee>) {
    const idx = this.creativeEmployees.findIndex(e => e.id === id);
    if (idx !== -1) {
      this.creativeEmployees[idx] = { ...this.creativeEmployees[idx], ...data };
      this.emitChange();
    }
  }

  public updateEmployeePermissions(id: string, perms: CreativePermission[]) {
    const emp = this.creativeEmployees.find(e => e.id === id);
    if (emp) {
      emp.permissions = perms;
      this.emitChange();
    }
  }

  public addBudget(budget: Omit<CreativeBudget, 'id' | 'createdAt'>) {
    const newBudget = { ...budget, id: `B${Date.now()}`, createdAt: Date.now() };
    this.creativeBudgets.push(newBudget);
    this.emitChange();
  }

  public approveBudget(id: string) {
    const budget = this.creativeBudgets.find(b => b.id === id);
    if (budget) {
      budget.status = 'APROVADO';
      
      const contractId = `CON${Date.now()}`;
      this.creativeContracts.push({
        id: contractId, budgetId: budget.id, clientName: budget.clientName,
        projectName: budget.description, value: budget.totalValue, deadline: budget.deadline, status: 'ATIVO'
      });

      this.creativeProjects.push({
        id: `CP${Date.now()}`, clientName: budget.clientName, furnitureType: budget.description,
        description: budget.description, measurements: 'A definir', material: budget.materials,
        deadline: budget.deadline, value: budget.totalValue, status: 'ORCAMENTO', createdAt: Date.now()
      });

      this.addFinanceEntry({
        description: `Contrato: ${budget.description} - ${budget.clientName}`,
        type: 'ENTRADA', category: 'RECEITA', value: budget.totalValue, date: new Date().toISOString().split('T')[0], relatedId: contractId
      });

      this.emitChange();
    }
  }

  public addFinanceEntry(entry: Omit<CreativeFinanceEntry, 'id'>) {
    this.creativeFinance.unshift({ ...entry, id: `F${Date.now()}` });
    this.emitChange();
  }

  public updateProjectStatus(id: string, status: CreativeProject['status']) {
    const proj = this.creativeProjects.find(p => p.id === id);
    if (proj) {
      proj.status = status;
      this.emitChange();
    }
  }

  // --- GETTERS ---
  public getCreativeMaterials() { return this.creativeMaterials; }
  public getCreativeProjects() { return this.creativeProjects; }
  public getCreativeEmployees() { return this.creativeEmployees; }
  public getCreativeBudgets() { return this.creativeBudgets; }
  public getCreativeContracts() { return this.creativeContracts; }
  public getCreativeFinance() { return this.creativeFinance; }

  // --- CORE SYSTEM METHODS ---
  public login(identifier: string, pass: string) {
    const user = this.users.find(u => u.cpf === identifier || u.id === identifier || u.username === identifier);
    if (!user) return { success: false, error: 'Usuário não encontrado' };
    if (user.password !== pass) return { success: false, error: 'Senha incorreta' };
    return { success: true, role: user.role, user };
  }

  // Fix: Explicit return type to resolve "Property 'error' does not exist on type '{ success: boolean; }'" in Landing.tsx
  public register(data: any): { success: boolean; error?: string } {
    const newUser = {
      id: `u${Date.now()}`,
      status: data.role === UserRole.CLIENT ? 'APPROVED' : 'PENDING',
      ...data
    };
    this.users.push(newUser);
    this.logAudit(newUser.name, newUser.role, 'REGISTER', `New ${newUser.role} registered`, 'INFO');
    this.emitChange();
    return { success: true };
  }

  public getAuditLogs() { return this.auditLogs; }
  public getPlatformStats() {
    return { totalUsers: this.users.length, totalVolume: 12500, totalOrders: 45, platformFees: 1875 };
  }

  private logAudit(actor: string, role: UserRole, action: string, details: string, severity: AuditLog['severity']) {
    this.auditLogs.unshift({ id: `${Date.now()}`, timestamp: new Date().toLocaleTimeString(), actor, role, action, target: 'CREATIVE', details, severity });
  }

  public createNotification(data: any) {
    this.notifications.unshift({ id: `n${Date.now()}`, time: 'Agora', read: false, ...data });
    this.emitChange();
  }

  public getNotifications(userId: string, role: string) {
    return this.notifications.filter(n => !n.target || n.target.userId === userId || n.target.role === role || n.target.role === 'ALL');
  }

  public getAllNotificationsForAdmin() {
    return this.notifications;
  }

  public cancelNotification(id: string) {
    const n = this.notifications.find(x => x.id === id);
    if (n) n.status = 'CANCELLED';
    this.emitChange();
  }

  public getStores() { return this.stores; }
  public getCities(): City[] { return this.cities; }
  public addCity(city: Omit<City, 'id'>) {
    this.cities.push({ id: `city${Date.now()}`, ...city });
    this.emitChange();
  }
  public removeCity(id: string) {
    this.cities = this.cities.filter(c => c.id !== id);
    this.emitChange();
  }

  public getAddresses(uid: string): Address[] { return this.addresses[uid] || []; }
  public addAddress(uid: string, addr: Omit<Address, 'id'>) {
    if (!this.addresses[uid]) this.addresses[uid] = [];
    this.addresses[uid].push({ id: `addr${Date.now()}`, ...addr });
    this.emitChange();
  }
  public removeAddress(uid: string, aid: string) {
    if (this.addresses[uid]) this.addresses[uid] = this.addresses[uid].filter(a => a.id !== aid);
    this.emitChange();
  }

  public getTasks(uid: string) { return this.tasks.filter(t => t.userId === uid); }
  public addTask(uid: string, title: string, description: string) {
    this.tasks.push({ id: `t${Date.now()}`, userId: uid, title, description, status: 'PENDING', createdAt: Date.now() });
    this.emitChange();
  }
  public completeTask(tid: string) {
    const t = this.tasks.find(x => x.id === tid);
    if (t) t.status = 'DONE';
    this.emitChange();
  }
  public deleteTask(tid: string) {
    this.tasks = this.tasks.filter(x => x.id !== tid);
    this.emitChange();
  }

  public getOrders(role: UserRole, uid?: string): Order[] { 
    if (role === UserRole.ADMIN) return this.orders;
    if (role === UserRole.CLIENT) return this.orders.filter(o => o.customerId === uid);
    if (role === UserRole.VENDOR) return this.orders.filter(o => o.storeId === uid);
    if (role === UserRole.DELIVERY) return this.orders;
    return [];
  }
  public updateOrderStatus(id: string, status: string, actor: string, role: UserRole) {
    const o = this.orders.find(x => x.id === id);
    if (o) {
      o.status = status;
      o.updatedAt = Date.now();
      this.logAudit(actor, role, 'UPDATE_ORDER', `Order ${id} status to ${status}`, 'INFO');
      this.emitChange();
    }
  }

  public getProducts(sid: string): Product[] { return []; }
  public addProduct(p: any) { this.emitChange(); }
  public deleteVendorProduct(id: string) { this.emitChange(); }

  public getAllUsers() { return this.users; }
  public updateUserStatus(id: string, status: string) {
    const u = this.users.find(x => x.id === id);
    if (u) {
      u.status = status;
      this.emitChange();
    }
  }
  public deleteUser(id: string) {
    this.users = this.users.filter(u => u.id !== id);
    this.emitChange();
  }

  public getPromotionalItems() { return { stores: this.stores, couriers: [] }; }
  public getStoreCouriers(sid: string) { return []; }
  public addVendorCourier(c: any) { this.emitChange(); }
  public getCourierVehicles(cid: string) { return []; }
  public addVehicle(cid: string, v: any) { this.emitChange(); }
  public addVendorVehicle(v: any) { this.emitChange(); }
  public updateStoreSettings(sid: string, settings: any) { this.emitChange(); }
  public getStoreStats(sid: string) { return { totalSales: 0, orderCount: 0, products: [] }; }
  public getCourierDetails(cid: string) { return { deliveries: 0, vehicles: [] }; }

  public submitReview(author: string, target: string, rating: number, comment: string, type: string) {
    this.emitChange();
  }

  public getCourierFinancials(cid: string) { return { balance: 1450, pending: 200, blocked: 0, transactions: [] }; }
  public getCourierReviews(cid: string) { return []; }
  public getCourierGamification(cid: string) { return { level: 5, xp: 2450, nextLevelXp: 2500, badges: ['Top Entregador'] }; }
  public getCourierProfile(cid: string) { return this.users.find(u => u.id === cid) || { name: 'Demo', email: 'demo@demo.com' }; }
  public requestWithdrawal(cid: string, amount: number) { return { success: true, message: 'Ok' }; }
  public getCourierStatus(cid: string) { return 'OFFLINE'; }
  public setCourierStatus(cid: string, status: string) { this.emitChange(); }

  public getOrCreateChatSession(oid: string, role: UserRole, uid: string) { return { id: 'chat1' }; }
  public getMessagesForOrder(oid: string) { return []; }
  public sendMessage(oid: string, sender: string, role: UserRole, text: string, isMe: boolean) { this.emitChange(); }
  public assignCourier(oid: string, cid: string, cname: string) { this.emitChange(); return true; }
  public rejectOrder(oid: string, cid: string) { this.emitChange(); }
  public validateCollectionToken(oid: string, token: string) { return { success: true, message: 'Coleta validada' }; }
  public validateDeliveryToken(oid: string, token: string) { return { success: true, message: 'Entrega validada' }; }
  public reportOrderIssue(oid: string, text: string) { this.emitChange(); }

  public getOccurrences() { return []; }
  public resolveOccurrence(id: string, action: string, actor: string, details: string) { this.emitChange(); }
  public getFraudAlerts() { return []; }
  public getTransactions() { return this.transactions; }
  public simulateWalletTransaction(uid: string, amount: number, type: string) {
    this.transactions.unshift({ id: `t${Date.now()}`, date: 'Hoje', type: type === 'DEPOSIT' ? 'ENTRADA' : 'SAIDA', category: 'CARTEIRA', details: type === 'DEPOSIT' ? 'Depósito via PIX' : 'Transferência bancária', amount });
    this.emitChange();
  }

  public getMaintenanceMode() { return this.maintenanceMode; }
  public setMaintenanceMode(val: boolean, actor: string) { this.maintenanceMode = val; this.emitChange(); }
  public getWeather() { return this.weatherCondition; }
  public setWeather(val: any, actor: string) { this.weatherCondition = val; this.emitChange(); }

  public getChats() { return []; }
  public getTickets() { return []; }
  public getReviews() { return []; }
  public getMarketingCampaigns() { return []; }
  public getPartners() { return []; }
  public getPages() { return []; }

  public subscribe(cb: Function) { 
    this.subscribers.push(cb); 
    return () => { this.subscribers = this.subscribers.filter(s => s !== cb); }; 
  }
  private emitChange() { this.subscribers.forEach(cb => cb()); }
}

export const carboSystem = new CarboSystem();
