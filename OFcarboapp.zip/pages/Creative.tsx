
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { SectionTitle, Card, Badge, Button, Input, Tabs, Avatar, Modal } from '../components/UIComponents';
import { 
  Hammer, Ruler, LayoutGrid, Package, ClipboardList, Clock, 
  Users, Trash2, Calendar, DollarSign, TrendingUp, Search, 
  FileText, ShieldCheck, Plus, CheckCircle2, AlertTriangle, 
  ArrowRight, MoveRight, UserCog, Filter, History, Handshake,
  Briefcase, BarChart2, MessageSquare, Terminal, X, Heart, Maximize2,
  // Fix: Import missing icons
  Check, Lock
} from 'lucide-react';
import { 
  CreativeMaterial, CreativeProject, CreativeEmployee, 
  CreativeBudget, CreativeContract, CreativeFinanceEntry,
  CreativePermission, UserRole
} from '../types';
import { carboSystem } from '../services/carboSystem';
import { motion, AnimatePresence } from 'framer-motion';

export const CreativePanel: React.FC = () => {
    const [activeTab, setActiveTab] = useState('Dashboard');
    const [projects, setProjects] = useState<CreativeProject[]>([]);
    const [materials, setMaterials] = useState<CreativeMaterial[]>([]);
    const [employees, setEmployees] = useState<CreativeEmployee[]>([]);
    const [budgets, setBudgets] = useState<CreativeBudget[]>([]);
    const [contracts, setContracts] = useState<CreativeContract[]>([]);
    const [finance, setFinance] = useState<CreativeFinanceEntry[]>([]);
    
    // Search & Filter State
    const [searchTerm, setSearchTerm] = useState('');
    const [modal, setModal] = useState<{ type: string; data?: any } | null>(null);

    // Dedication Logic
    const [showDedication, setShowDedication] = useState(false);
    const [lastActivity, setLastActivity] = useState(Date.now());
    const INACTIVITY_LIMIT = 10 * 60 * 1000; // 10 minutes

    const updateData = useCallback(() => {
        setProjects(carboSystem.getCreativeProjects());
        setMaterials(carboSystem.getCreativeMaterials());
        setEmployees(carboSystem.getCreativeEmployees());
        setBudgets(carboSystem.getCreativeBudgets());
        setContracts(carboSystem.getCreativeContracts());
        setFinance(carboSystem.getCreativeFinance());
    }, []);

    useEffect(() => {
        updateData();
        // Show dedication on mount (first login simulation)
        setShowDedication(true);
        return carboSystem.subscribe(updateData);
    }, [updateData]);

    // Inactivity Monitor
    useEffect(() => {
        const resetTimer = () => {
            setLastActivity(Date.now());
            if (showDedication) setShowDedication(false);
        };

        const events = ['mousemove', 'keydown', 'mousedown', 'touchstart'];
        events.forEach(e => window.addEventListener(e, resetTimer));

        const interval = setInterval(() => {
            if (Date.now() - lastActivity > INACTIVITY_LIMIT && !showDedication) {
                setShowDedication(true);
            }
        }, 10000);

        return () => {
            events.forEach(e => window.removeEventListener(e, resetTimer));
            clearInterval(interval);
        };
    }, [lastActivity, showDedication]);

    const filteredData = useMemo(() => {
        if (!searchTerm) return null;
        const s = searchTerm.toLowerCase();
        return {
            projects: projects.filter(p => p.clientName.toLowerCase().includes(s) || p.furnitureType.toLowerCase().includes(s)),
            budgets: budgets.filter(b => b.clientName.toLowerCase().includes(s) || b.description.toLowerCase().includes(s)),
            contracts: contracts.filter(c => c.clientName.toLowerCase().includes(s) || c.projectName.toLowerCase().includes(s)),
            employees: employees.filter(e => e.name.toLowerCase().includes(s) || e.role.toLowerCase().includes(s)),
            materials: materials.filter(m => m.name.toLowerCase().includes(s)),
            finance: finance.filter(f => f.description.toLowerCase().includes(s) || f.category.toLowerCase().includes(s))
        };
    }, [searchTerm, projects, budgets, contracts, employees, materials, finance]);

    const renderDashboard = () => (
        <div className="space-y-8 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="flex items-center gap-4 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                    <div className="p-4 bg-orange-50 dark:bg-orange-950/30 text-carbo-primary rounded-2xl"><Hammer size={24}/></div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Em Produção</p>
                        <h3 className="text-2xl font-black text-gray-900 dark:text-zinc-100">{projects.filter(p => p.status === 'PRODUCAO').length}</h3>
                    </div>
                </Card>
                <Card className="flex items-center gap-4 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                    <div className="p-4 bg-blue-50 dark:bg-blue-950/30 text-blue-600 rounded-2xl"><ClipboardList size={24}/></div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Orçamentos</p>
                        <h3 className="text-2xl font-black text-gray-900 dark:text-zinc-100">{budgets.filter(b => b.status === 'ENVIADO').length}</h3>
                    </div>
                </Card>
                <Card className="flex items-center gap-4 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                    <div className="p-4 bg-green-50 dark:bg-green-950/30 text-green-600 rounded-2xl"><Handshake size={24}/></div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Contratos Ativos</p>
                        <h3 className="text-2xl font-black text-gray-900 dark:text-zinc-100">{contracts.filter(c => c.status === 'ATIVO' || c.status === 'EM_ANDAMENTO').length}</h3>
                    </div>
                </Card>
                <Card className="flex items-center gap-4 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                    <div className="p-4 bg-purple-50 dark:bg-purple-950/30 text-purple-600 rounded-2xl"><DollarSign size={24}/></div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Receita Mensal</p>
                        <h3 className="text-2xl font-black text-gray-900 dark:text-zinc-100">R$ {finance.filter(f => f.type === 'ENTRADA').reduce((acc, f) => acc + f.value, 0).toLocaleString()}</h3>
                    </div>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                    <h4 className="font-bold text-gray-900 dark:text-zinc-100 mb-6 flex items-center gap-2"><Clock size={18} className="text-carbo-primary"/> Prazos e Cronograma</h4>
                    <div className="space-y-4">
                        {projects.length === 0 && <p className="text-xs text-gray-400 italic">Nenhum projeto em andamento.</p>}
                        {projects.filter(p => p.status !== 'CONCLUIDO').slice(0, 4).map(p => (
                            <div key={p.id} className="flex justify-between items-center p-4 bg-white/50 dark:bg-zinc-800/40 rounded-2xl border border-white/20 dark:border-white/5">
                                <div>
                                    <p className="text-sm font-bold text-gray-900 dark:text-zinc-200">{p.clientName}</p>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase">{p.furnitureType}</p>
                                </div>
                                <div className="text-right">
                                    <Badge variant="neutral" className="text-[10px]">{p.deadline}</Badge>
                                    <p className="text-[9px] text-gray-400 font-black mt-1 uppercase">{p.status}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </Card>
                <Card className="bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5 flex flex-col">
                    <h4 className="font-bold text-gray-900 dark:text-zinc-100 mb-6 flex items-center gap-2"><TrendingUp size={18} className="text-green-600"/> Resumo Financeiro Interno</h4>
                    <div className="flex-1 flex flex-col justify-center items-center py-8">
                        <div className="text-center">
                            <p className="text-xs text-gray-400 font-black uppercase tracking-widest mb-1">Balanço do Período</p>
                            <h2 className="text-4xl font-black text-green-600">R$ { (finance.filter(f => f.type === 'ENTRADA').reduce((a, b) => a + b.value, 0) - finance.filter(f => f.type === 'SAIDA').reduce((a, b) => a + b.value, 0)).toLocaleString() }</h2>
                        </div>
                        <div className="grid grid-cols-2 gap-8 mt-10 w-full">
                            <div className="text-center">
                                <p className="text-[10px] text-gray-400 font-black uppercase">Entradas</p>
                                <p className="text-lg font-bold text-green-500">R$ {finance.filter(f => f.type === 'ENTRADA').reduce((a, b) => a + b.value, 0).toLocaleString()}</p>
                            </div>
                            <div className="text-center border-l border-white/10">
                                <p className="text-[10px] text-gray-400 font-black uppercase">Saídas</p>
                                <p className="text-lg font-bold text-red-400">R$ {finance.filter(f => f.type === 'SAIDA').reduce((a, b) => a + b.value, 0).toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );

    const renderSearch = () => (
        <div className="space-y-8 animate-in fade-in duration-500">
            <div className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                    autoFocus
                    placeholder="Busca — Creative (Clientes, Projetos, Equipe, Finanças...)" 
                    className="w-full pl-16 pr-6 py-5 bg-white/60 dark:bg-zinc-900/40 backdrop-blur-xl border border-white/20 dark:border-white/5 rounded-3xl shadow-soft outline-none focus:ring-4 focus:ring-carbo-primary/10 transition-all font-bold text-lg text-gray-900 dark:text-zinc-100 placeholder-gray-400 dark:placeholder-zinc-600"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>

            {searchTerm && filteredData ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {filteredData.projects.length > 0 && (
                        <div className="space-y-4">
                            <h5 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest ml-1">Projetos & Produção</h5>
                            {filteredData.projects.map(p => (
                                <Card key={p.id} className="p-5 flex justify-between items-center bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                                    <div>
                                        <p className="font-bold text-gray-900 dark:text-zinc-100">{p.clientName}</p>
                                        <p className="text-xs text-gray-500">{p.furnitureType}</p>
                                    </div>
                                    <Badge variant="primary">{p.status}</Badge>
                                </Card>
                            ))}
                        </div>
                    )}
                    {filteredData.employees.length > 0 && (
                        <div className="space-y-4">
                            <h5 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest ml-1">Funcionários</h5>
                            {filteredData.employees.map(e => (
                                <Card key={e.id} className="p-5 flex items-center gap-4 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                                    <Avatar fallback={e.name[0]} size="md"/>
                                    <div>
                                        <p className="font-bold text-gray-900 dark:text-zinc-100">{e.name}</p>
                                        <p className="text-xs text-gray-500">{e.role}</p>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    )}
                    {filteredData.budgets.length > 0 && (
                        <div className="space-y-4">
                            <h5 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest ml-1">Orçamentos</h5>
                            {filteredData.budgets.map(b => (
                                <Card key={b.id} className="p-5 flex justify-between items-center bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                                    <span>{b.clientName}</span>
                                    <span className="font-black">R$ {b.totalValue.toLocaleString()}</span>
                                </Card>
                            ))}
                        </div>
                    )}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-32 text-gray-300 dark:text-zinc-800">
                    <Terminal size={64} className="mb-6 opacity-20"/>
                    <p className="font-black text-xl uppercase tracking-widest">Filtro Ativo: Creative</p>
                    <p className="text-sm mt-2 opacity-60">Aguardando comando de busca avançada...</p>
                </div>
            )}
        </div>
    );

    const renderKanban = () => {
        const columns = ['ORCAMENTO', 'PRODUCAO', 'ACABAMENTO', 'ENTREGA', 'CONCLUIDO'];
        const labels: any = { ORCAMENTO: 'Orçamentos', PRODUCAO: 'Em Produção', ACABAMENTO: 'Acabamento', ENTREGA: 'Pronto / Entrega', CONCLUIDO: 'Finalizados' };
        
        return (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6 h-[75vh] overflow-x-auto pb-8 items-start custom-scrollbar">
                {columns.map(col => (
                    <div key={col} className="min-w-[280px] flex flex-col gap-5">
                        <div className="px-3 flex justify-between items-center">
                            <h4 className="text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500 tracking-[0.2em]">{labels[col]}</h4>
                            <Badge variant="neutral" className="bg-white/50 dark:bg-zinc-800/50 border-none shadow-inner">{projects.filter(p => p.status === col).length}</Badge>
                        </div>
                        <div className="p-3 bg-white/20 dark:bg-zinc-900/30 backdrop-blur-md rounded-[2.5rem] border border-white/10 dark:border-white/5 min-h-[150px] flex flex-col gap-4">
                            {projects.filter(p => p.status === col).map(p => (
                                <Card key={p.id} className="p-5 cursor-grab active:cursor-grabbing hover:border-carbo-primary dark:hover:border-carbo-primary transition-all group bg-white/60 dark:bg-zinc-800/40 shadow-sm border-white/40 dark:border-white/5">
                                    <div className="flex justify-between items-start mb-3">
                                        <h5 className="font-bold text-sm text-gray-900 dark:text-zinc-200 line-clamp-1">{p.clientName}</h5>
                                        <button className="text-gray-300 dark:text-zinc-700 hover:text-carbo-primary transition-colors"><Maximize2 size={12}/></button>
                                    </div>
                                    <p className="text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500 mb-4">{p.furnitureType}</p>
                                    <div className="flex justify-between items-center pt-3 border-t border-gray-100/50 dark:border-zinc-700/50">
                                        <div className="flex items-center gap-1.5">
                                            <Calendar size={10} className="text-gray-400" />
                                            <span className="text-[9px] font-black text-gray-400 uppercase">{p.deadline}</span>
                                        </div>
                                        <MoveRight size={14} className="text-gray-300 dark:text-zinc-700 group-hover:text-carbo-primary group-hover:translate-x-1 transition-all"/>
                                    </div>
                                </Card>
                            ))}
                            {projects.filter(p => p.status === col).length === 0 && (
                                <div className="flex-1 flex items-center justify-center py-10 opacity-10">
                                    <Package size={32} />
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const renderFinance = () => (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex justify-between items-center">
                <SectionTitle title="Financeiro Interno" subtitle="Fluxo de caixa e controle de custos Creative." className="mb-0" />
                <div className="flex gap-3">
                    <Button variant="secondary" icon={<Filter size={18}/>}>Filtros</Button>
                    <Button icon={<Plus size={18}/>} onClick={() => setModal({ type: 'NEW_FINANCE' })}>Novo Lançamento</Button>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                <Card className="p-6 bg-green-50 dark:bg-green-950/20 border-green-100 dark:border-green-900/30">
                    <p className="text-[10px] font-black uppercase text-green-600 dark:text-green-400 tracking-widest mb-1">Entradas Totais</p>
                    <p className="text-2xl font-black text-green-700 dark:text-green-300">R$ {finance.filter(f => f.type === 'ENTRADA').reduce((a,b) => a + b.value, 0).toLocaleString()}</p>
                </Card>
                <Card className="p-6 bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/30">
                    <p className="text-[10px] font-black uppercase text-red-600 dark:text-red-400 tracking-widest mb-1">Saídas Totais</p>
                    <p className="text-2xl font-black text-red-700 dark:text-red-300">R$ {finance.filter(f => f.type === 'SAIDA').reduce((a,b) => a + b.value, 0).toLocaleString()}</p>
                </Card>
                <Card className="p-6 bg-white dark:bg-zinc-900/40 shadow-inner">
                    <p className="text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500 tracking-widest mb-1">Saldo Atual</p>
                    <p className="text-2xl font-black text-gray-900 dark:text-zinc-100">R$ {(finance.filter(f => f.type === 'ENTRADA').reduce((a,b) => a + b.value, 0) - finance.filter(f => f.type === 'SAIDA').reduce((a,b) => a + b.value, 0)).toLocaleString()}</p>
                </Card>
            </div>

            <Card className="overflow-hidden p-0 border-white/20 dark:border-white/5 bg-white/40 dark:bg-zinc-900/20">
                <table className="w-full text-left">
                    <thead className="bg-gray-100/50 dark:bg-zinc-800/50 text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500">
                        <tr>
                            <th className="px-8 py-5">Data</th>
                            <th className="px-8 py-5">Descrição</th>
                            <th className="px-8 py-5">Categoria</th>
                            <th className="px-8 py-5 text-right">Valor</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100/30 dark:divide-zinc-800/30">
                        {finance.map(f => (
                            <tr key={f.id} className="hover:bg-white/40 dark:hover:bg-zinc-800/40 transition-colors">
                                <td className="px-8 py-5 text-xs text-gray-500 font-mono">{f.date}</td>
                                <td className="px-8 py-5 text-sm font-bold text-gray-900 dark:text-zinc-200">{f.description}</td>
                                <td className="px-8 py-5"><Badge variant="neutral" className="text-[9px] font-black">{f.category}</Badge></td>
                                <td className={`px-8 py-5 text-right font-black ${f.type === 'ENTRADA' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                    {f.type === 'ENTRADA' ? '+' : '-'} R$ {f.value.toLocaleString()}
                                </td>
                            </tr>
                        ))}
                        {finance.length === 0 && (
                            <tr><td colSpan={4} className="p-12 text-center text-gray-400 italic">Nenhum registro financeiro nesta unidade.</td></tr>
                        )}
                    </tbody>
                </table>
            </Card>
        </div>
    );

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-32">
            <div className="flex flex-col md:flex-row justify-between md:items-end gap-6 border-b border-gray-100 dark:border-zinc-800/50 pb-8">
                <div>
                    <Badge variant="primary" className="mb-2 shadow-glow">Creative Marcenaria</Badge>
                    <SectionTitle title="Painel do Guilherme" subtitle="Gestão operacional, produção e crescimento da Creative." className="mb-0" />
                </div>
                <Tabs 
                    tabs={['Dashboard', 'Busca Avançada', 'Funcionários', 'Orçamentos', 'Contratos', 'Kanban', 'Estoque', 'Finanças']} 
                    activeTab={activeTab} 
                    onChange={setActiveTab} 
                />
            </div>

            <main>
                {activeTab === 'Dashboard' && renderDashboard()}
                {activeTab === 'Busca Avançada' && renderSearch()}
                {activeTab === 'Funcionários' && (
                    <div className="space-y-6 animate-in fade-in">
                        <div className="flex justify-between items-center">
                            <SectionTitle title="Equipe Operacional" subtitle="Controle de acessos e performance da oficina." className="mb-0" />
                            <Button icon={<Plus size={18}/>} onClick={() => setModal({ type: 'NEW_EMPLOYEE' })}>Novo Colaborador</Button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {employees.map(emp => (
                                <Card key={emp.id} className="flex justify-between items-center group bg-white/40 dark:bg-zinc-900/20">
                                    <div className="flex items-center gap-4">
                                        <Avatar fallback={emp.name[0]} size="md" />
                                        <div>
                                            <h4 className="font-bold text-gray-900 dark:text-zinc-100">{emp.name}</h4>
                                            <p className="text-[10px] font-black uppercase text-gray-400">{emp.role}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant={emp.status === 'ATIVO' ? 'success' : 'neutral'}>{emp.status}</Badge>
                                        <button onClick={() => setModal({ type: 'PERMISSIONS', data: emp })} className="p-2.5 bg-gray-100 dark:bg-zinc-800 rounded-xl text-gray-400 hover:text-carbo-primary transition-all">
                                            <UserCog size={18} />
                                        </button>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </div>
                )}
                {activeTab === 'Orçamentos' && (
                    <div className="space-y-6 animate-in fade-in">
                        <div className="flex justify-between items-center">
                            <SectionTitle title="Central de Orçamentos" subtitle="Propostas comerciais enviadas e em negociação." className="mb-0" />
                            <Button icon={<Plus size={18}/>} onClick={() => setModal({ type: 'NEW_BUDGET' })}>Criar Orçamento</Button>
                        </div>
                        <div className="space-y-4">
                            {budgets.map(b => (
                                <Card key={b.id} className="flex justify-between items-center bg-white/40 dark:bg-zinc-900/20">
                                    <div className="flex items-center gap-6">
                                        <div className="w-12 h-12 bg-white/80 dark:bg-zinc-800/80 rounded-2xl flex items-center justify-center text-carbo-primary shadow-sm">
                                            <FileText size={20}/>
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-gray-900 dark:text-zinc-100">{b.clientName}</h4>
                                            <p className="text-xs text-gray-500">{b.description}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-10">
                                        <div className="text-right">
                                            <p className="font-black text-gray-900 dark:text-zinc-200">R$ {b.totalValue.toLocaleString()}</p>
                                            <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{b.deadline}</p>
                                        </div>
                                        <Badge variant={b.status === 'APROVADO' ? 'success' : b.status === 'REJEITADO' ? 'danger' : 'neutral'}>
                                            {b.status}
                                        </Badge>
                                        {b.status === 'ENVIADO' && (
                                            <button onClick={() => carboSystem.approveBudget(b.id)} className="p-3 bg-green-500 text-white rounded-2xl shadow-lg shadow-green-500/20 hover:scale-105 transition-all">
                                                <Check size={18} strokeWidth={3} />
                                            </button>
                                        )}
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </div>
                )}
                {activeTab === 'Contratos' && (
                    <div className="space-y-6 animate-in fade-in">
                        <SectionTitle title="Contratos & Compromissos" subtitle="Controle jurídico e financeiro dos projetos fechados." />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {contracts.map(c => (
                                <Card key={c.id} className="bg-white/40 dark:bg-zinc-900/20">
                                    <div className="flex justify-between mb-6">
                                        <div>
                                            <h4 className="font-bold text-gray-900 dark:text-zinc-100">{c.projectName}</h4>
                                            <p className="text-xs text-gray-400">Contrato #{c.id}</p>
                                        </div>
                                        <Badge variant="success" className="h-fit shadow-glow">{c.status}</Badge>
                                    </div>
                                    <div className="space-y-3 mb-6">
                                        <p className="text-sm text-gray-600 dark:text-zinc-400 flex items-center gap-2 font-medium"><Users size={14} className="text-gray-400"/> Cliente: <strong>{c.clientName}</strong></p>
                                        <p className="text-sm text-gray-600 dark:text-zinc-400 flex items-center gap-2 font-medium"><Calendar size={14} className="text-gray-400"/> Entrega: <strong>{c.deadline}</strong></p>
                                    </div>
                                    <div className="flex justify-between items-center border-t border-gray-100/50 dark:border-zinc-700/50 pt-5">
                                        <span className="font-black text-gray-900 dark:text-zinc-100 text-lg">R$ {c.value.toLocaleString()}</span>
                                        <Button variant="ghost" size="sm">Ver Documento</Button>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </div>
                )}
                {activeTab === 'Kanban' && renderKanban()}
                {activeTab === 'Estoque' && (
                    <div className="space-y-6 animate-in fade-in">
                        <SectionTitle title="Estoque de Materiais" subtitle="Controle de chapas, ferragens e insumos da oficina." />
                        <Card className="overflow-hidden p-0 bg-white/40 dark:bg-zinc-900/20 border-white/20 dark:border-white/5">
                             <table className="w-full text-left">
                                <thead className="bg-gray-100/50 dark:bg-zinc-800/50 text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500">
                                    <tr><th className="px-8 py-5">Material</th><th className="px-8 py-5 text-center">Quantidade</th><th className="px-8 py-5 text-right">Status</th></tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100/30 dark:divide-zinc-800/30">
                                    {materials.map(m => (
                                        <tr key={m.id} className="hover:bg-white/40 dark:hover:bg-zinc-800/40 transition-colors">
                                            <td className="px-8 py-5 font-bold text-gray-900 dark:text-zinc-200">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-2 h-2 rounded-full bg-carbo-primary" />
                                                    {m.name}
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 text-center font-black dark:text-zinc-300">{m.quantity} {m.unit}</td>
                                            <td className="px-8 py-5 text-right">
                                                <Badge variant={m.quantity <= m.minStock ? 'danger' : 'success'} className={m.quantity <= m.minStock ? 'shadow-[0_0_15px_rgba(239,68,68,0.2)]' : ''}>
                                                    {m.quantity <= m.minStock ? 'Estoque Baixo' : 'Em Estoque'}
                                                </Badge>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                             </table>
                        </Card>
                    </div>
                )}
                {activeTab === 'Finanças' && renderFinance()}
            </main>

            {/* MODALS */}
            <Modal isOpen={!!modal} onClose={() => setModal(null)} title={modal?.type === 'PERMISSIONS' ? `Permissões: ${modal?.data?.name}` : 'Ação de Cadastro'}>
                {modal?.type === 'PERMISSIONS' && (
                    <div className="space-y-4">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30 rounded-2xl flex items-start gap-3 mb-6">
                            <ShieldCheck size={20} className="text-blue-500 shrink-0 mt-0.5" />
                            <p className="text-xs text-blue-800 dark:text-blue-300">Defina o nível de acesso para cada módulo operacional. Mudanças impactam a navegação do usuário em tempo real.</p>
                        </div>
                        {['Dashboard', 'Orçamentos', 'Contratos', 'Projetos', 'Kanban', 'Estoque', 'Finanças', 'Funcionários'].map(mod => (
                            <div key={mod} className="flex justify-between items-center p-4 bg-gray-50/50 dark:bg-zinc-800/40 rounded-2xl border border-gray-100 dark:border-zinc-700/50">
                                <span className="font-bold text-gray-700 dark:text-zinc-200 text-sm">{mod}</span>
                                <div className="flex gap-1.5 p-1 bg-white dark:bg-zinc-900 rounded-xl">
                                    {['NONE', 'VIEW', 'EDIT'].map(lv => (
                                        <button key={lv} className={`px-3 py-1.5 text-[9px] font-black rounded-lg transition-all ${lv === 'NONE' ? 'bg-gray-100 text-gray-400' : lv === 'VIEW' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'} hover:brightness-95`}>{lv}</button>
                                    ))}
                                </div>
                            </div>
                        ))}
                        <Button className="w-full mt-6 h-14 shadow-glow">Atualizar Permissões</Button>
                    </div>
                )}
                {modal?.type === 'NEW_EMPLOYEE' && (
                    <div className="space-y-4">
                        <Input label="Nome Completo" placeholder="Ex: João Silva" />
                        <div className="grid grid-cols-2 gap-4">
                            <Input label="Usuário de Acesso" placeholder="joao.silva" />
                            <Input label="Cargo/Função" placeholder="Marceneiro" />
                        </div>
                        <div className="p-5 bg-orange-50 dark:bg-orange-950/20 rounded-2xl border border-orange-100 dark:border-orange-800/30">
                            <p className="text-xs text-orange-700 dark:text-orange-400 font-bold mb-2 flex items-center gap-2"><Lock size={14}/> Credenciais Temporárias</p>
                            <p className="text-[10px] text-orange-600/80 dark:text-orange-500/80 leading-relaxed italic">A senha padrão será <strong>creative2025</strong>. O sistema forçará a alteração no primeiro login do colaborador.</p>
                        </div>
                        <Button className="w-full h-14" onClick={() => setModal(null)}>Criar Acesso</Button>
                    </div>
                )}
                {modal?.type === 'NEW_BUDGET' && (
                    <div className="space-y-5">
                        <Input label="Nome do Cliente" placeholder="Pessoa Física ou Empresa" />
                        <Input label="Descrição do Projeto" placeholder="Ex: Móveis planejados para suíte master" />
                        <div className="grid grid-cols-2 gap-4">
                            <Input label="Custos Materiais (R$)" type="number" placeholder="0.00" />
                            <Input label="Mão de Obra (R$)" type="number" placeholder="0.00" />
                        </div>
                        <Input label="Previsão de Entrega" type="date" />
                        <Button className="w-full h-14" onClick={() => setModal(null)}>Salvar Proposta</Button>
                    </div>
                )}
                {modal?.type === 'NEW_FINANCE' && (
                    <div className="space-y-5">
                        <div className="grid grid-cols-2 gap-4">
                            <button className="flex-1 p-4 bg-green-50 dark:bg-green-900/20 border-2 border-green-500 text-green-700 dark:text-green-400 rounded-2xl font-black text-sm uppercase">Entrada</button>
                            <button className="flex-1 p-4 bg-gray-50 dark:bg-zinc-800 border-2 border-transparent text-gray-400 rounded-2xl font-black text-sm uppercase">Saída</button>
                        </div>
                        <Input label="Descrição" placeholder="Ex: Pagamento Fornecedor Ferragens" />
                        <div className="grid grid-cols-2 gap-4">
                            <Input label="Valor (R$)" type="number" placeholder="0.00" />
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 ml-1">Categoria</label>
                                <select className="w-full bg-white/50 dark:bg-zinc-900/50 backdrop-blur-sm border border-gray-200 dark:border-zinc-700 text-gray-900 dark:text-zinc-100 rounded-2xl py-3 px-5 outline-none focus:ring-4 focus:ring-carbo-primary/10 transition-all font-bold">
                                    <option>Materiais</option>
                                    <option>Mão de Obra</option>
                                    <option>Custos Fixos</option>
                                    <option>Impostos</option>
                                    <option>Receita</option>
                                </select>
                            </div>
                        </div>
                        <Button className="w-full h-14" onClick={() => setModal(null)}>Registrar Movimentação</Button>
                    </div>
                )}
            </Modal>

            {/* DEDICATION MODAL / SCREENSAVER */}
            <AnimatePresence>
                {showDedication && (
                    <motion.div 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }} 
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/90 dark:bg-black/95 backdrop-blur-3xl"
                    >
                        <motion.div 
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            className="max-w-2xl w-full bg-white/10 border border-white/10 rounded-[3rem] p-12 text-center text-white shadow-2xl"
                        >
                            <Heart size={48} className="mx-auto text-carbo-primary mb-8 animate-pulse fill-carbo-primary/20" />
                            <h2 className="text-3xl font-black mb-10 tracking-tight leading-tight">Guilherme,</h2>
                            <div className="space-y-6 text-lg text-slate-300 font-medium leading-relaxed max-w-lg mx-auto">
                                <p>Este painel foi desenvolvido para apoiar o dia a dia da Creative, trazendo mais organização, controle e clareza nos projetos.</p>
                                <p>Ele existe para ajudar a empresa a crescer de forma estruturada, facilitando decisões, acompanhando o trabalho e fortalecendo tudo aquilo que vocês constroem todos os dias.</p>
                                <p>Que seja uma ferramenta de apoio constante no crescimento da Creative.</p>
                            </div>
                            <p className="mt-12 text-carbo-primary font-black uppercase tracking-[0.3em] text-sm">Bem-vindo ao Creative</p>
                            
                            <button 
                                onClick={() => setShowDedication(false)}
                                className="mt-12 px-10 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95"
                            >
                                Fechar Mensagem
                            </button>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};
