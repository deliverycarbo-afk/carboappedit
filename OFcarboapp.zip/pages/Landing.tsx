import React, { useState, useEffect } from 'react';
import { UserRole, City } from '../types';
import { Button, Input, Card, Badge, Modal, Stepper } from '../components/UIComponents';
import { Logo } from '../components/Logo';
import { 
  ShieldCheck, Truck, Store, User, ArrowRight, UploadCloud, 
  CheckCircle2, Lock, MapPin, CreditCard,
  ChevronLeft, LayoutGrid, Zap, BarChart2, MessageSquare, Package, 
  ShoppingBag, Award, Shield, AlertCircle, FileText, Briefcase, Menu, X, ArrowUpRight, Smartphone, Key, Users, Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { carboSystem } from '../services/carboSystem';

interface LandingProps {
  onLogin: (role: UserRole, user?: any) => void;
}

// --- CONSTANTS ---
const FEATURES = [
    { icon: <LayoutGrid size={24}/>, title: 'Pedidos Inteligentes', desc: 'Fluxo automatizado do pedido à entrega.' },
    { icon: <Truck size={24}/>, title: 'Leilão de Fretes', desc: 'Entregadores disputam corridas em tempo real.' },
    { icon: <CreditCard size={24}/>, title: 'Carteira Digital', desc: 'Pagamentos instantâneos e gestão financeira.' },
    { icon: <ShieldCheck size={24}/>, title: 'Antigolpe', desc: 'Tokens de segurança para coleta e entrega.' },
    { icon: <MessageSquare size={24}/>, title: 'Chat Seguro', desc: 'Comunicação auditada entre as partes.' },
    { icon: <BarChart2 size={24}/>, title: 'Gestão Completa', desc: 'Relatórios, estoque e controle de frota.' },
];

const ROLES_INFO = {
    VENDOR: { 
        title: 'Para Lojas e Restaurantes', 
        desc: 'Gerencie pedidos, estoque e entregadores próprios ou da rede Carbo.', 
        benefits: ['Cardápio Digital', 'Gestão de Motoboys', 'Conciliação Financeira'],
        cta: 'Vender com Carbo',
        role: UserRole.VENDOR
    },
    DELIVERY: { 
        title: 'Para Entregadores', 
        desc: 'Receba mais, escolha suas rotas e tenha segurança total.', 
        benefits: ['Sem taxas abusivas', 'Pagamento Rápido', 'Seguro Acidente'],
        cta: 'Ser um Entregador',
        role: UserRole.DELIVERY
    },
    CLIENT: { 
        title: 'Para Clientes', 
        desc: 'Acompanhe seus pedidos em tempo real com total transparência.', 
        benefits: ['Rastreamento GPS', 'Pagamento Seguro', 'Chat Direto'],
        cta: 'Criar Conta Grátis',
        role: UserRole.CLIENT
    }
};

const sanitizeNumeric = (val: string) => val.replace(/\D/g, '');

export const LandingPage: React.FC<LandingProps> = ({ onLogin }) => {
  // Navigation State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Modal States
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);

  // Login Form State
  const [loginId, setLoginId] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState('');

  // Register Form State
  const [regStep, setRegStep] = useState(0);
  const [regError, setRegError] = useState('');
  const [cities, setCities] = useState<City[]>([]);
  const [availableNeighborhoods, setAvailableNeighborhoods] = useState<string[]>([]);
  
  const [regData, setRegData] = useState({
    role: null as UserRole | null,
    subType: null as 'INTERNAL' | null, 
    name: '',
    surname: '',
    cpf: '',
    cnpj: '', 
    phone: '',
    email: '',
    password: '',
    confirmPassword: '', 
    storeName: '',
    docImage: null as string | null, 
    selfieImage: null as string | null, 
    address: {
        zip: '',
        street: '',
        number: '',
        neighborhood: '',
        city: ''
    },
    selectedModules: [] as string[]
  });

  // Scroll Effect
  useEffect(() => {
      const handleScroll = () => setScrolled(window.scrollY > 20);
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Load Cities
  useEffect(() => {
      setCities(carboSystem.getCities());
  }, []);

  // Update Neighborhoods when City changes
  useEffect(() => {
      const cityObj = cities.find(c => c.name === regData.address.city);
      setAvailableNeighborhoods(cityObj ? cityObj.neighborhoods : []);
  }, [regData.address.city, cities]);

  // --- HANDLERS ---

  const handleLoginSubmit = () => {
      setLoginError('');
      if (!loginId || !loginPass) {
          setLoginError('Preencha todos os campos.');
          return;
      }
      
      const result = carboSystem.login(loginId, loginPass);
      if (result.success && result.role) {
          onLogin(result.role, result.user);
      } else {
          setLoginError(result.error || 'Credenciais inválidas.');
      }
  };

  const handleRegisterSubmit = () => {
      // Final Validation handled inside steps, this is the commit
      const result = carboSystem.register({
          role: regData.role,
          name: `${regData.name} ${regData.surname}`.trim(),
          cpf: regData.cpf,
          password: regData.password,
          storeName: regData.storeName,
          email: regData.email,
          phone: regData.phone,
          city: regData.address.city, 
          neighborhoods: regData.role === UserRole.DELIVERY ? [regData.address.neighborhood] : undefined,
          address: regData.role === UserRole.CLIENT ? regData.address : undefined
      });

      if (result.success) {
          if (regData.role === UserRole.VENDOR || regData.role === UserRole.DELIVERY) {
              alert(`Cadastro recebido! Seu perfil está em análise (Status: Pendente). Você será notificado.`);
              setRegisterOpen(false);
              setRegStep(0);
          } else {
              const loginResult = carboSystem.login(regData.cpf, regData.password);
              onLogin(regData.role || UserRole.CLIENT, loginResult.user);
          }
      } else {
          setRegError(result.error || 'Erro ao criar conta.');
      }
  };

  const nextStep = () => {
      setRegError('');
      
      // Validation Logic
      if (regStep === 0) {
          if (!regData.role) return setRegError('Selecione um tipo de conta.');
      }
      if (regStep === 1) {
          if (!regData.name || !regData.surname || !regData.email || !regData.phone || !regData.cpf) return setRegError('Preencha todos os campos obrigatórios.');
          if (regData.password !== regData.confirmPassword) return setRegError('As senhas não conferem.');
          if (regData.password.length < 6) return setRegError('Senha muito curta.');
      }
      if (regStep === 2) {
          if (!regData.address.city || !regData.address.neighborhood || !regData.address.street || !regData.address.number) return setRegError('Endereço completo é obrigatório.');
      }
      if (regStep === 3) {
          if (regData.role === UserRole.VENDOR && !regData.storeName) return setRegError('Nome da loja é obrigatório.');
          if ((regData.role === UserRole.VENDOR || regData.role === UserRole.DELIVERY) && (!regData.docImage)) return setRegError('Envio de documento obrigatório.');
      }

      if (regStep < 4) setRegStep(curr => curr + 1);
      else handleRegisterSubmit();
  };

  const prevStep = () => {
      setRegError('');
      if (regStep > 0) setRegStep(curr => curr - 1);
  };

  const openRegister = (role?: UserRole) => {
      setRegData(prev => ({ ...prev, role: role || null }));
      setRegStep(role ? 1 : 0); // Skip role selection if provided
      setRegisterOpen(true);
      setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-gray-900 font-sans selection:bg-carbo-primary selection:text-white">
      
      {/* --- 1. HEADER (FIXO) --- */}
      <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
          <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
              <Logo size={scrolled ? "md" : "lg"} />
              
              {/* Desktop Menu */}
              <nav className="hidden md:flex items-center gap-8">
                  {['Como funciona', 'Recursos', 'Segurança', 'Para quem é'].map(item => (
                      <a key={item} href={`#${item.toLowerCase().replace(/\s/g, '-')}`} className="text-sm font-bold text-gray-600 hover:text-carbo-primary transition-colors">{item}</a>
                  ))}
              </nav>

              {/* Desktop Auth Buttons */}
              <div className="hidden md:flex items-center gap-4">
                  <button onClick={() => setLoginOpen(true)} className="text-sm font-bold text-gray-900 hover:text-carbo-primary transition-colors">Entrar</button>
                  <Button onClick={() => openRegister()} className="shadow-lg shadow-orange-500/20">Criar Conta</Button>
              </div>

              {/* Mobile Menu Toggle */}
              <button className="md:hidden p-2" onClick={() => setMobileMenuOpen(true)}>
                  <Menu size={24} />
              </button>
          </div>
      </header>

      {/* --- MOBILE MENU --- */}
      <AnimatePresence>
          {mobileMenuOpen && (
              <motion.div 
                  initial={{ opacity: 0, x: '100%' }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: '100%' }}
                  className="fixed inset-0 z-[60] bg-white flex flex-col p-6"
              >
                  <div className="flex justify-between items-center mb-8">
                      <Logo size="md" />
                      <button onClick={() => setMobileMenuOpen(false)} className="p-2 bg-gray-100 rounded-full"><X size={24}/></button>
                  </div>
                  <nav className="flex flex-col gap-6 text-lg font-bold text-gray-800">
                      {['Como funciona', 'Recursos', 'Segurança'].map(item => (
                          <a key={item} href="#" onClick={() => setMobileMenuOpen(false)}>{item}</a>
                      ))}
                  </nav>
                  <div className="mt-auto space-y-4">
                      <Button onClick={() => { setMobileMenuOpen(false); setLoginOpen(true); }} variant="outline" className="w-full justify-center">Entrar</Button>
                      <Button onClick={() => openRegister()} className="w-full justify-center">Criar Conta Grátis</Button>
                  </div>
              </motion.div>
          )}
      </AnimatePresence>

      {/* --- 2. HERO SECTION --- */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[1000px] bg-gradient-to-b from-orange-100/50 to-transparent rounded-full blur-3xl -z-10 pointer-events-none" />
          
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left">
                  <Badge variant="primary" className="mb-6 inline-flex px-4 py-1.5 text-sm">Novo Sistema v2.0</Badge>
                  <h1 className="text-4xl md:text-6xl font-black text-gray-900 leading-tight mb-6">
                      Conectando <span className="text-carbo-primary">logística</span> e vendas em um só lugar.
                  </h1>
                  <p className="text-lg text-gray-600 mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
                      Pedidos inteligentes, leilão de fretes, tokens de segurança e gestão financeira completa para clientes, lojas e entregadores.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                      <Button size="lg" className="h-14 px-8 text-base shadow-xl shadow-orange-500/20" onClick={() => openRegister()}>Começar Agora</Button>
                      <Button size="lg" variant="secondary" className="h-14 px-8 text-base" onClick={() => setLoginOpen(true)}>Acessar Sistema</Button>
                  </div>
                  <div className="mt-8 flex items-center justify-center lg:justify-start gap-6 text-sm font-bold text-gray-500">
                      <span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-green-500"/> Grátis para começar</span>
                      <span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-green-500"/> Sem fidelidade</span>
                  </div>
              </div>

              {/* Visual Hero Cards */}
              <div className="relative h-[500px] hidden lg:block">
                  <motion.div 
                      animate={{ y: [0, -20, 0] }} transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
                      className="absolute top-10 right-10 z-10"
                  >
                      <Card className="w-72 p-5 border-l-4 border-l-green-500 shadow-2xl">
                          <div className="flex justify-between items-start mb-3">
                              <Badge variant="success">Novo Pedido</Badge>
                              <span className="text-xs font-bold text-gray-400">Agora</span>
                          </div>
                          <h4 className="font-bold text-gray-900">X-Burger Premium (2x)</h4>
                          <div className="mt-3 flex justify-between items-center">
                              <div className="flex -space-x-2"><div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white"/><div className="w-8 h-8 rounded-full bg-gray-300 border-2 border-white"/></div>
                              <span className="font-black text-lg text-green-600">R$ 45,90</span>
                          </div>
                      </Card>
                  </motion.div>

                  <motion.div 
                      animate={{ y: [0, 20, 0] }} transition={{ repeat: Infinity, duration: 7, ease: "easeInOut", delay: 1 }}
                      className="absolute bottom-20 left-10 z-20"
                  >
                      <Card className="w-80 p-5 border-l-4 border-l-blue-500 shadow-2xl bg-white/90 backdrop-blur-md">
                          <div className="flex items-center gap-4 mb-4">
                              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600"><Truck size={24}/></div>
                              <div><h4 className="font-bold">Leilão de Frete</h4><p className="text-xs text-gray-500">Nova corrida disponível</p></div>
                          </div>
                          <div className="flex gap-2">
                              <Button size="sm" className="w-full">Aceitar R$ 12,00</Button>
                          </div>
                      </Card>
                  </motion.div>
                  
                  {/* Decorative Elements */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-orange-100 to-blue-50 rounded-[3rem] -z-10 rotate-3 transform scale-90 border border-white/50" />
              </div>
          </div>
      </section>

      {/* --- 3. COMO FUNCIONA (ROLES) --- */}
      <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-6">
              <div className="text-center mb-16">
                  <h2 className="text-3xl font-black text-gray-900">Um ecossistema, múltiplas soluções</h2>
                  <p className="text-gray-500 mt-4 max-w-2xl mx-auto">O Carbo integra todas as pontas da cadeia logística em uma única plataforma inteligente.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {Object.values(ROLES_INFO).map((role, idx) => (
                      <div key={idx} className="group p-8 rounded-[2rem] border border-gray-100 bg-slate-50 hover:bg-white hover:shadow-xl transition-all duration-300 relative overflow-hidden">
                          <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-carbo-primary mb-6 group-hover:scale-110 transition-transform">
                              {role.role === UserRole.VENDOR ? <Store size={28}/> : role.role === UserRole.DELIVERY ? <Truck size={28}/> : <User size={28}/>}
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 mb-3">{role.title}</h3>
                          <p className="text-gray-600 text-sm leading-relaxed mb-6">{role.desc}</p>
                          <ul className="space-y-3 mb-8">
                              {role.benefits.map((b, i) => (
                                  <li key={i} className="flex items-center gap-3 text-sm font-medium text-gray-700">
                                      <Check size={16} className="text-green-500" /> {b}
                                  </li>
                              ))}
                          </ul>
                          <Button variant="outline" className="w-full group-hover:bg-carbo-primary group-hover:text-white group-hover:border-carbo-primary" onClick={() => openRegister(role.role)}>
                              {role.cta}
                          </Button>
                      </div>
                  ))}
              </div>
          </div>
      </section>

      {/* --- 4. FUNCIONALIDADES --- */}
      <section className="py-20 bg-slate-50">
          <div className="max-w-7xl mx-auto px-6">
              <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
                  <div>
                      <h2 className="text-3xl font-black text-gray-900">Tudo o que você precisa</h2>
                      <p className="text-gray-500 mt-2">Ferramentas poderosas para otimizar sua operação.</p>
                  </div>
                  <Button variant="ghost" className="text-carbo-primary">Ver todos os recursos <ArrowRight size={16}/></Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {FEATURES.map((feat, i) => (
                      <Card key={i} className="p-6 hover:-translate-y-1 transition-transform border-none shadow-sm hover:shadow-md">
                          <div className="w-12 h-12 bg-orange-50 text-carbo-primary rounded-xl flex items-center justify-center mb-4">
                              {feat.icon}
                          </div>
                          <h4 className="font-bold text-gray-900 mb-2">{feat.title}</h4>
                          <p className="text-sm text-gray-500 leading-relaxed">{feat.desc}</p>
                      </Card>
                  ))}
              </div>
          </div>
      </section>

      {/* --- 5. SEGURANÇA --- */}
      <section className="py-20 bg-gray-900 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-carbo-primary blur-[150px] opacity-10 rounded-full" />
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
              <div>
                  <Badge variant="warning" className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 mb-6">Segurança em Primeiro Lugar</Badge>
                  <h2 className="text-4xl font-black mb-6">Proteção total para cada entrega.</h2>
                  <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                      Utilizamos tecnologia de ponta para garantir que produtos, pagamentos e pessoas estejam sempre seguros durante todo o processo.
                  </p>
                  <div className="space-y-6">
                      {[
                          { title: 'Tokens de Validação', desc: 'Códigos únicos para coleta e entrega garantem que o pedido chegue à pessoa certa.' },
                          { title: 'Chat Auditável', desc: 'Toda comunicação fica registrada para resolver disputas rapidamente.' },
                          { title: 'Monitoramento em Tempo Real', desc: 'Acompanhe o trajeto exato do entregador no mapa.' }
                      ].map((item, i) => (
                          <div key={i} className="flex gap-4">
                              <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center shrink-0">
                                  <Shield size={20} className="text-green-400" />
                              </div>
                              <div>
                                  <h4 className="font-bold text-lg">{item.title}</h4>
                                  <p className="text-sm text-gray-400 mt-1">{item.desc}</p>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
              <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-transparent z-10 lg:hidden" />
                  <div className="bg-gray-800 rounded-3xl p-8 border border-gray-700 shadow-2xl relative rotate-3 hover:rotate-0 transition-transform duration-500">
                      <div className="flex justify-between items-center mb-8">
                          <h3 className="font-black text-2xl">Validação de Entrega</h3>
                          <Badge variant="success">Seguro</Badge>
                      </div>
                      <div className="bg-gray-900 rounded-xl p-6 text-center border border-gray-700 mb-6">
                          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Token do Cliente</p>
                          <p className="text-5xl font-mono font-black text-white tracking-[0.5em]">8492</p>
                      </div>
                      <p className="text-center text-sm text-gray-400">O entregador só finaliza a corrida após inserir este código.</p>
                  </div>
              </div>
          </div>
      </section>

      {/* --- 7. CTA FINAL --- */}
      <section className="py-24 bg-white text-center">
          <div className="max-w-4xl mx-auto px-6">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-6 tracking-tight">Pronto para revolucionar sua logística?</h2>
              <p className="text-xl text-gray-500 mb-10">Junte-se a milhares de lojas e entregadores que já usam o Carbo.</p>
              <Button size="lg" className="h-16 px-12 text-lg shadow-2xl shadow-orange-500/30 hover:scale-105 transition-transform" onClick={() => openRegister()}>
                  Criar Minha Conta Agora
              </Button>
              <p className="mt-6 text-sm text-gray-400 font-medium">Sem cartão de crédito necessário • Cancelamento a qualquer momento</p>
          </div>
      </section>

      {/* --- 8. FOOTER --- */}
      <footer className="bg-slate-50 border-t border-gray-200 py-16">
          <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
              <div className="col-span-1 md:col-span-1">
                  <Logo size="md" />
                  <p className="text-sm text-gray-500 mt-4">O sistema operacional da logística moderna.</p>
              </div>
              <div>
                  <h4 className="font-bold text-gray-900 mb-4">Produto</h4>
                  <ul className="space-y-2 text-sm text-gray-500">
                      <li><a href="#" className="hover:text-carbo-primary">Para Lojas</a></li>
                      <li><a href="#" className="hover:text-carbo-primary">Para Entregadores</a></li>
                      <li><a href="#" className="hover:text-carbo-primary">Preços</a></li>
                  </ul>
              </div>
              <div>
                  <h4 className="font-bold text-gray-900 mb-4">Legal</h4>
                  <ul className="space-y-2 text-sm text-gray-500">
                      <li><a href="#" className="hover:text-carbo-primary">Termos de Uso</a></li>
                      <li><a href="#" className="hover:text-carbo-primary">Privacidade</a></li>
                      <li><a href="#" className="hover:text-carbo-primary">Compliance</a></li>
                  </ul>
              </div>
              <div>
                  <h4 className="font-bold text-gray-900 mb-4">Contato</h4>
                  <p className="text-sm text-gray-500">suporte@carbo.app</p>
                  <div className="flex gap-4 mt-4">
                      {/* Social Icons Placeholders */}
                      <div className="w-8 h-8 bg-gray-200 rounded-full"/>
                      <div className="w-8 h-8 bg-gray-200 rounded-full"/>
                      <div className="w-8 h-8 bg-gray-200 rounded-full"/>
                  </div>
              </div>
          </div>
          <div className="max-w-7xl mx-auto px-6 mt-12 pt-8 border-t border-gray-200 text-center text-xs text-gray-400">
              &copy; 2025 CarboApp. Todos os direitos reservados.
          </div>
      </footer>

      {/* --- LOGIN MODAL --- */}
      <Modal 
          isOpen={loginOpen} 
          onClose={() => setLoginOpen(false)} 
          title="Acessar Conta"
      >
          <div className="space-y-6">
              <div className="text-center">
                  <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4 text-carbo-primary">
                      <Key size={24}/>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Bem-vindo de volta!</h3>
                  <p className="text-sm text-gray-500">Insira suas credenciais para continuar.</p>
              </div>

              <div className="space-y-4">
                  <Input 
                      label="Identificador" 
                      placeholder="guilherme, email ou CPF" 
                      value={loginId}
                      onChange={(e) => setLoginId(e.target.value)}
                      icon={<User size={18}/>}
                  />
                  <div>
                      <Input 
                          label="Senha" 
                          type="password" 
                          placeholder="••••••••" 
                          value={loginPass}
                          onChange={(e) => setLoginPass(e.target.value)}
                          icon={<Lock size={18}/>}
                      />
                      <div className="text-right mt-1">
                          <button className="text-xs text-carbo-primary font-bold hover:underline">Esqueci minha senha</button>
                      </div>
                  </div>
                  
                  {loginError && (
                      <div className="p-3 bg-red-50 border border-red-100 rounded-lg flex items-center gap-2 text-sm text-red-600 font-medium">
                          <AlertCircle size={16} /> {loginError}
                      </div>
                  )}

                  <Button className="w-full h-12" onClick={handleLoginSubmit}>Entrar no Sistema</Button>
              </div>

              <div className="pt-6 border-t border-gray-100 text-center">
                  <p className="text-sm text-gray-500">Ainda não tem conta?</p>
                  <button onClick={() => { setLoginOpen(false); openRegister(); }} className="text-sm font-bold text-gray-900 hover:text-carbo-primary mt-1">Criar conta gratuita</button>
              </div>
              
              {/* DEV HINT */}
              <div className="bg-gray-50 p-3 rounded-lg text-[10px] text-gray-400 text-center font-mono">
                  Guilherme: guilherme / meriva1515<br/>
                  Dev: 111/123 (Admin), 222/123 (Loja), 333/123 (Entregador), 444/123 (Cliente)
              </div>
          </div>
      </Modal>

      {/* --- REGISTER WIZARD MODAL --- */}
      <Modal 
          isOpen={registerOpen} 
          onClose={() => setRegisterOpen(false)} 
          title="Criar Nova Conta"
      >
          <div className="space-y-6">
              {/* Progress Bar */}
              <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden mb-6">
                  <motion.div 
                      className="h-full bg-carbo-primary" 
                      initial={{ width: 0 }} 
                      animate={{ width: `${((regStep + 1) / 5) * 100}%` }}
                  />
              </div>

              {/* STEP 0: ROLE SELECTION */}
              {regStep === 0 && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                      <h3 className="text-lg font-bold text-gray-900 text-center mb-6">Como você deseja usar o Carbo?</h3>
                      <div className="grid gap-3">
                          {[
                              { r: UserRole.CLIENT, t: 'Cliente', d: 'Quero fazer pedidos e entregas.', i: <User size={24}/> },
                              { r: UserRole.VENDOR, t: 'Loja / Vendedor', d: 'Quero vender e gerenciar entregas.', i: <Store size={24}/> },
                              { r: UserRole.DELIVERY, t: 'Entregador', d: 'Quero trabalhar fazendo entregas.', i: <Truck size={24}/> },
                          ].map(opt => (
                              <button 
                                  key={opt.r} 
                                  onClick={() => setRegData({...regData, role: opt.r})}
                                  className={`flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all ${regData.role === opt.r ? 'border-carbo-primary bg-orange-50' : 'border-gray-100 hover:border-gray-200'}`}
                              >
                                  <div className={`p-3 rounded-full ${regData.role === opt.r ? 'bg-carbo-primary text-white' : 'bg-gray-100 text-gray-500'}`}>{opt.i}</div>
                                  <div>
                                      <h4 className="font-bold text-gray-900">{opt.t}</h4>
                                      <p className="text-xs text-gray-500">{opt.d}</p>
                                  </div>
                              </button>
                          ))}
                      </div>
                  </div>
              )}

              {/* STEP 1: PERSONAL DATA */}
              {regStep === 1 && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                      <h3 className="text-lg font-bold text-gray-900 text-center">Seus Dados Pessoais</h3>
                      <div className="grid grid-cols-2 gap-4">
                          <Input label="Nome" value={regData.name} onChange={e => setRegData({...regData, name: e.target.value})} />
                          <Input label="Sobrenome" value={regData.surname} onChange={e => setRegData({...regData, surname: e.target.value})} />
                      </div>
                      <Input label="CPF" value={regData.cpf} onChange={e => setRegData({...regData, cpf: sanitizeNumeric(e.target.value)})} placeholder="000.000.000-00" />
                      <Input label="Celular" value={regData.phone} onChange={e => setRegData({...regData, phone: sanitizeNumeric(e.target.value)})} placeholder="(00) 00000-0000" />
                      <Input label="Email" type="email" value={regData.email} onChange={e => setRegData({...regData, email: e.target.value})} placeholder="seu@email.com" />
                      <div className="grid grid-cols-2 gap-4">
                          <Input label="Senha" type="password" value={regData.password} onChange={e => setRegData({...regData, password: e.target.value})} />
                          <Input label="Confirmar" type="password" value={regData.confirmPassword} onChange={e => setRegData({...regData, confirmPassword: e.target.value})} />
                      </div>
                  </div>
              )}

              {/* STEP 2: ADDRESS */}
              {regStep === 2 && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                      <h3 className="text-lg font-bold text-gray-900 text-center">Onde você está?</h3>
                      <div>
                          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Cidade</label>
                          <select 
                              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-carbo-primary/20 outline-none transition-all"
                              value={regData.address.city}
                              onChange={e => setRegData({...regData, address: {...regData.address, city: e.target.value, neighborhood: ''}})}
                          >
                              <option value="">Selecione...</option>
                              {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                          </select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Bairro</label>
                              <select 
                                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-carbo-primary/20 outline-none transition-all"
                                  value={regData.address.neighborhood}
                                  onChange={e => setRegData({...regData, address: {...regData.address, neighborhood: e.target.value}})}
                                  disabled={!regData.address.city}
                              >
                                  <option value="">Selecione...</option>
                                  {availableNeighborhoods.map(n => <option key={n} value={n}>{n}</option>)}
                              </select>
                          </div>
                          <Input label="CEP" value={regData.address.zip} onChange={e => setRegData({...regData, address: {...regData.address, zip: sanitizeNumeric(e.target.value)}})} />
                      </div>
                      <Input label="Endereço" value={regData.address.street} onChange={e => setRegData({...regData, address: {...regData.address, street: e.target.value}})} />
                      <Input label="Número" value={regData.address.number} onChange={e => setRegData({...regData, address: {...regData.address, number: e.target.value}})} />
                  </div>
              )}

              {/* STEP 3: SPECIFICS (Vendor/Courier Only) */}
              {regStep === 3 && regData.role !== UserRole.CLIENT && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                      <h3 className="text-lg font-bold text-gray-900 text-center">
                          {regData.role === UserRole.VENDOR ? 'Dados do Negócio' : 'Dados Profissionais'}
                      </h3>
                      
                      {regData.role === UserRole.VENDOR && (
                          <Input label="Nome Fantasia da Loja" value={regData.storeName} onChange={e => setRegData({...regData, storeName: e.target.value})} placeholder="Ex: Burger King Centro" />
                      )}

                      <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl text-sm text-blue-800">
                          <p className="font-bold flex items-center gap-2 mb-2"><ShieldCheck size={16}/> Validação Obrigatória</p>
                          <p>Para manter a segurança da plataforma, precisamos validar sua identidade.</p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                          <div className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center gap-2 cursor-pointer hover:bg-gray-50 transition-colors ${regData.docImage ? 'border-green-500 bg-green-50' : 'border-gray-200'}`}>
                              <UploadCloud size={24} className={regData.docImage ? 'text-green-600' : 'text-gray-400'}/>
                              <span className="text-xs font-bold text-gray-500">{regData.docImage ? 'Documento Enviado' : 'Foto do RG/CNH'}</span>
                              <input type="file" className="hidden" onChange={(e) => e.target.files?.[0] && setRegData({...regData, docImage: 'ok'})} />
                          </div>
                          <div className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center gap-2 cursor-pointer hover:bg-gray-50 transition-colors ${regData.selfieImage ? 'border-green-500 bg-green-50' : 'border-gray-200'}`}>
                              <Smartphone size={24} className={regData.selfieImage ? 'text-green-600' : 'text-gray-400'}/>
                              <span className="text-xs font-bold text-gray-500">{regData.selfieImage ? 'Selfie Recebida' : 'Selfie com Doc'}</span>
                              <input type="file" className="hidden" onChange={(e) => e.target.files?.[0] && setRegData({...regData, selfieImage: 'ok'})} />
                          </div>
                      </div>
                  </div>
              )}

              {/* STEP 4: CONFIRMATION */}
              {(regStep === 4 || (regStep === 3 && regData.role === UserRole.CLIENT)) && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 text-center">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600 mb-4">
                          <CheckCircle2 size={40} />
                      </div>
                      <h3 className="text-2xl font-black text-gray-900">Tudo Pronto!</h3>
                      <p className="text-gray-500">Revise seus dados e confirme para criar sua conta.</p>
                      
                      <div className="bg-gray-50 p-4 rounded-xl text-left text-sm space-y-2 border border-gray-100">
                          <div className="flex justify-between">
                              <span className="text-gray-500">Perfil:</span>
                              <span className="font-bold text-gray-900">{regData.role}</span>
                          </div>
                          <div className="flex justify-between">
                              <span className="text-gray-500">Nome:</span>
                              <span className="font-bold text-gray-900">{regData.name} {regData.surname}</span>
                          </div>
                          <div className="flex justify-between">
                              <span className="text-gray-500">Email:</span>
                              <span className="font-bold text-gray-900">{regData.email}</span>
                          </div>
                          {regData.role === UserRole.VENDOR && (
                              <div className="flex justify-between">
                                  <span className="text-gray-500">Loja:</span>
                                  <span className="font-bold text-gray-900">{regData.storeName}</span>
                              </div>
                          )}
                      </div>

                      {regData.role !== UserRole.CLIENT && (
                          <div className="text-xs text-orange-600 font-bold bg-orange-50 p-3 rounded-lg">
                              * Sua conta entrará em análise (aprox. 2h)
                          </div>
                      )}
                  </div>
              )}

              {regError && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm font-bold rounded-lg border border-red-100 flex items-center gap-2">
                      <AlertCircle size={16}/> {regError}
                  </div>
              )}

              <div className="flex gap-3 pt-4 border-t border-gray-100">
                  {regStep > 0 && (
                      <Button variant="secondary" onClick={prevStep} className="flex-1">Voltar</Button>
                  )}
                  <Button onClick={nextStep} className="flex-1 shadow-lg shadow-orange-500/20">
                      {(regStep === 4 || (regStep === 3 && regData.role === UserRole.CLIENT)) ? 'Finalizar Cadastro' : 'Continuar'}
                  </Button>
              </div>
          </div>
      </Modal>

    </div>
  );
};