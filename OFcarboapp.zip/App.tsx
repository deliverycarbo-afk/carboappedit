import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { LandingPage } from './pages/Landing';
import { ClientDashboard, ClientP2P, ClientMarketplace, ClientOrders } from './pages/Client';
import { 
  VendorDashboard, VendorKanban, VendorInventory, VendorDelivery,
  VendorCouriers, VendorVehicles, VendorFinance, VendorChat, VendorReviews, 
  VendorCompetitors, VendorNotifications, VendorSettings, VendorMarketing
} from './pages/Vendor';
import { CreativePanel } from './pages/Creative';
import { DeliveryDashboard, DeliveryHistory, DeliveryVehicles } from './pages/Delivery';
import { 
    AdminDashboard, AdminUsers, AdminFinance, AdminApprovals, AdminSupport, 
    AdminPermissions, AdminOrderMonitor, AdminPlatformSettings, AdminChatMonitor, 
    AdminReviews, AdminTokens, AdminNotifications, AdminReports, AdminMarketing, 
    AdminPartners, AdminContent, AdminSecurity 
} from './pages/Admin';
import { WalletPage, SettingsPage } from './pages/Common';
import { UserRole } from './types';

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<UserRole>(UserRole.GUEST);
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [user, setUser] = useState<any>(null);

  const handleLogin = (role: UserRole, authenticatedUser?: any) => {
    setUserRole(role);
    setUser(authenticatedUser);
    
    // Explicit redirection for Guilherme
    if (authenticatedUser?.id === 'guilherme') {
      setCurrentPage('creative_panel');
      return;
    }

    // Default redirections
    switch(role) {
      case UserRole.VENDOR: setCurrentPage('vendor_dashboard'); break;
      case UserRole.DELIVERY: setCurrentPage('delivery_home'); break;
      case UserRole.CLIENT: setCurrentPage('client_home'); break;
      case UserRole.ADMIN: setCurrentPage('admin_dash'); break;
      default: setCurrentPage('home');
    }
  };

  const handleLogout = () => {
    setUserRole(UserRole.GUEST);
    setUser(null);
    setCurrentPage('home');
  };

  const renderContent = () => {
    if (currentPage === 'wallet') return <WalletPage />;
    if (currentPage === 'settings') return <SettingsPage />;

    // Specialized Creative Panel Route
    if (currentPage === 'creative_panel') return <CreativePanel />;

    // Client Context
    if (userRole === UserRole.CLIENT) {
      if (currentPage === 'client_home' || currentPage === 'home') return <ClientDashboard />;
      if (currentPage === 'client_p2p') return <ClientP2P />;
      if (currentPage === 'client_orders') return <ClientOrders />;
    }

    // Vendor Context
    if (userRole === UserRole.VENDOR) {
      if (currentPage === 'vendor_dashboard' || currentPage === 'home') return <VendorDashboard />;
      if (currentPage === 'vendor_kanban') return <VendorKanban />;
      if (currentPage === 'vendor_inventory') return <VendorInventory />;
      if (currentPage === 'vendor_marketing') return <VendorMarketing />;
      if (currentPage === 'vendor_delivery') return <VendorDelivery />;
      if (currentPage === 'vendor_couriers') return <VendorCouriers />;
      if (currentPage === 'vendor_vehicles') return <VendorVehicles />;
      if (currentPage === 'vendor_finance') return <VendorFinance />;
      if (currentPage === 'vendor_chat') return <VendorChat />;
      if (currentPage === 'vendor_reviews') return <VendorReviews />;
      if (currentPage === 'vendor_competitors') return <VendorCompetitors />;
      if (currentPage === 'vendor_notifications') return <VendorNotifications />;
      if (currentPage === 'vendor_settings' || currentPage === 'vendor_customization') return <VendorSettings />;
    }

    // Delivery Context
    if (userRole === UserRole.DELIVERY) {
      if (currentPage === 'delivery_home' || currentPage === 'home') return <DeliveryDashboard />;
      if (currentPage === 'delivery_history') return <DeliveryHistory />;
      if (currentPage === 'delivery_vehicles') return <DeliveryVehicles />;
    }

    // Admin Context
    if (userRole === UserRole.ADMIN) {
      if (currentPage === 'admin_dash' || currentPage === 'home') return <AdminDashboard />;
      if (currentPage === 'admin_users') return <AdminUsers />;
      if (currentPage === 'admin_finance') return <AdminFinance />;
      if (currentPage === 'admin_approvals') return <AdminApprovals />;
      if (currentPage === 'admin_security') return <AdminSecurity />;
      if (currentPage === 'admin_marketing') return <AdminMarketing />;
      if (currentPage === 'admin_partners') return <AdminPartners />;
      if (currentPage === 'admin_content') return <AdminContent />;
      if (currentPage === 'admin_support') return <AdminSupport />;
      if (currentPage === 'admin_permissions') return <AdminPermissions />;
      if (currentPage === 'admin_orders') return <AdminOrderMonitor />;
      if (currentPage === 'admin_platform') return <AdminPlatformSettings />;
      if (currentPage === 'admin_chats') return <AdminChatMonitor />;
      if (currentPage === 'admin_reviews') return <AdminReviews />;
      if (currentPage === 'admin_tokens') return <AdminTokens />;
      if (currentPage === 'admin_notifications') return <AdminNotifications />;
      if (currentPage === 'admin_reports') return <AdminReports />;
    }

    return <div className="p-10 text-center text-gray-500">Página não encontrada ou sem permissão.</div>;
  };

  if (userRole === UserRole.GUEST) {
    return <LandingPage onLogin={handleLogin} />;
  }

  return (
    <Layout 
      role={userRole} 
      currentPage={currentPage} 
      onNavigate={setCurrentPage}
      onLogout={handleLogout}
      userId={user?.id}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
